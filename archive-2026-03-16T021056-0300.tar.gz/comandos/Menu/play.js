const ytdl = require('@distube/ytdl-core');
const yts = require('yt-search');
const fs = require('fs');
const path = require('path');

// Nos aseguramos 100% de que la carpeta de descargas exista
const tempFolder = path.join(process.cwd(), 'temp');
if (!fs.existsSync(tempFolder)) {
    fs.mkdirSync(tempFolder);
}

module.exports = {
    nombre: 'play',
    ejecutar: async (sock, msg, args) => {
        const from = msg.key.remoteJid;
        
        if (!args.length) return await sock.sendMessage(from, { text: '🦋 *Euphoria:* Escribe el nombre de la canción, babe. Ej: *!play Feid*' }, { quoted: msg });

        const query = args.join(' ');
        await sock.sendMessage(from, { text: `⏳ *Buscando:* _${query}_... ✨` }, { quoted: msg });

        try {
            // Buscamos el video
            const searchResults = await yts(query);
            const video = searchResults.videos.slice(0, 1)[0];
            
            if (!video) {
                return await sock.sendMessage(from, { text: '❌ *Error:* No encontré nada, intenta ser más específico.' }, { quoted: msg });
            }

            // Confirmamos qué canción encontró
            await sock.sendMessage(from, { 
                image: { url: video.thumbnail }, 
                caption: `╭━━〔 🎵 *ＭÚＳＩＣＡ* 🎵 〕━━╮\n┃\n┃ ✨ *Título:* ${video.title}\n┃ ⏳ *Duración:* ${video.timestamp}\n┃ 💜 *Estado:* Descargando audio...\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━━╯` 
            }, { quoted: msg });

            // Configuramos la descarga con el sistema antibloqueos de YouTube
            const audioStream = ytdl(video.url, { 
                filter: 'audioonly', 
                quality: 'highestaudio',
                highWaterMark: 1 << 25 // Esto evita que YouTube corte la descarga de videos oficiales
            });
            
            const tempFile = path.join(tempFolder, `${Date.now()}.mp3`);
            const fileStream = fs.createWriteStream(tempFile);
            
            audioStream.pipe(fileStream);

            fileStream.on('finish', async () => {
                try {
                    // Enviamos el audio
                    await sock.sendMessage(from, { 
                        audio: { url: tempFile }, 
                        mimetype: 'audio/mp4',
                        fileName: `${video.title}.mp3`
                    }, { quoted: msg });

                    // Limpiamos la basura del servidor
                    if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
                } catch (sendError) {
                    console.error('Error al enviar el mensaje:', sendError);
                }
            });

            audioStream.on('error', async (error) => {
                console.error('Error de YouTube:', error);
                await sock.sendMessage(from, { text: '❌ *Ups:* YouTube bloqueó esta descarga en específico. Intenta buscar la canción agregando la palabra "lyrics" o "letra".' }, { quoted: msg });
                if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
            });

        } catch (error) {
            console.error('Error en comando play:', error);
            await sock.sendMessage(from, { text: '❌ *Error:* Ocurrió un fallo general. Intenta más tarde.' }, { quoted: msg });
        }
    }
}